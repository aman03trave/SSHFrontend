import 'package:flutter/material.dart';

void showCustomSnackBar(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(
        message,
        style: TextStyle(color: Colors.black),
      ),
      behavior: SnackBarBehavior.floating,
      margin: EdgeInsets.only(top: 0, left: 20, right: 20, bottom: 800),
      duration: Duration(seconds: 3),
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: BorderSide(color: Colors.black),
      ),
    ),
  );
}
